# Configure Microsoft FSLogix Profile Containers with OCI Secure Desktops using ZFS SMB

# Task 1 — Create ZFSSA instances using marketplace image



# Task 2 — Configure the ZFSSA

Login to the ZFFSA using the root username and password configured in the previous steps

![image\.png](Images_attachments/image%2013.png)

Navigate to Configuration \> Services and enable the SMB service under Data Services, and verify DNS service is enabled and configured with the appropriate DNS servers\.

![image\.png](Images_attachments/image%2012.png)

![image\.png](Images_attachments/image%2016.png)

Select Active Directory under Directory Services and enable this service

Click JOIN DOMAIN and enter the AD domain, User, Password then click APPLY to join the domain

![image\.png](Images_attachments/image%205.png)

![image\.png](Images_attachments/image%2018.png)



Navigate to Configuration =\> Storage in the ZFSSA UI to verify ZFSSA pool:

![image\.png](Images_attachments/image%209.png)

Next go to Shares tab, click Projects, Click plus to create a project name\. Then create a File System by selecting Shares, click File Systems and click plus sign\.

![image\.png](Images_attachments/image%201.png)

Note: The filesystem permission in the screenshot above is set as everyone@ which allows access to all users\. To limit access, you should assign permissions to specific users or groups\.

![image\.png](Images_attachments/image%2015.png)

![image\.png](Images_attachments/image%202.png)

Navigate to Shares \> Access, under Root Directory ACL, click plus sign to add new entry for Everyone Type, Click Edit Entry and set the desired permissions for the \(Owner/Group/Everyone\) Types as shown below:

![image\.png](Images_attachments/image%206.png)

Owner Type:

Group/Everyone Type:



# Task 3 — Configure NTFS permissions for ZFSSA SMB share

1. Open File Explorer and select This PC

2. Enter \\\<share\> in the address bar at the top

3. Create a “profiles” folder within the share to store all user profiles

4. Right click on the profile folder and choose Properties

5. Navigate to the Security tab

6. Click on “Advanced” to configure

![image\.png](Images_attachments/image%2021.png)

Adding new Principals \(Domain Users, Domain Admins and CREATOR OWNER\) for the “profiles” folder by following these steps: Domain Users • Click Add • In the new Permission Entry windows, click Select a Principal • Enter the name of the user/group \(Domain Users\) then click Check Names and OK

Add domain users

![image\.png](Images_attachments/image%2010.png)

![image\.png](Images_attachments/image%2011.png)



Add domain admins

![image\.png](Images_attachments/image.png)

![image\.png](Images_attachments/image%203.png)

Add creator owner

![image\.png](Images_attachments/image%2020.png)

![image\.png](Images_attachments/image%2014.png)

Remove all other users from the ZFSSA Profiles folder, retaining only these three users: CREATOR OWNER, Domain Admins, and Domain Users\. To remove a user who has inherited permissions from the parent folder, you need to break the inheritance first by following these steps\.

- In the Advanced Security Settings window, click on ‘Disable inheritance’\.

- A prompt will appear\. Select ‘Convert inherited permissions into explicit permissions on this object’\. This allows you to edit or remove these permissions for specific users

- Find the user you want to remove \(e\.g\., Current Owner\), select them, and click Remove

- Click Apply and then OK

After completing these steps, the Advanced Security Settings for the Profiles folder should appear as shown below

![image\.png](Images_attachments/image%2017.png)





# Task 4 — Deploy and configure FSLogix in Secure Desktop to create a Golden Image

Visit the official Microsoft download page for FSLogix and download the latest version of the FSLogix installer \(https://learn\.microsoft\.com/en\-us/fslogix/how\-to\-install\-fslogix\) • Install FSLogix on Windows 11 desktop and verify that FSLogix app is installed successfully

![image\.png](Images_attachments/image%208.png)



Copy file 

![image\.png](Images_attachments/image%207.png)

fslogix\.adml\.  To\.   C:\\Windows\\PolicyDefinitions\\en\-US

fslogix\.admx\. To\.   C:\\Windows\\PolicyDefinitions





Next, configure Profile Container Settings • Type ‘gpedit\.msc’ and press Enter • Navigate to: Computer Configuration\>Administrative Templates\>FSLogix\>Profile Containers • Configure these key settings

![image\.png](Images_attachments/image%204.png)

NOTE: The following settings in FSLogix Profile Container should be enabled, with the specific individual settings/values configured as indicated below\.

![image\.png](Images_attachments/image%2019.png)

- Delete Local Profile When VHD Should Apply : Enabled

- Locked Retry Count \(count = 3\)

- Locked Retry Interval \(interval = 15\)

- Profile Type \(profile type = Normal profile\)

- Reattach Count \(count = 3\)

- Reattach Interval \(internal = 15\)

- Roam Identity \(enabled\)

- Size in MBs \(size = 30000\) Go to Computer Configuration\>Administrative Templates\>FSLogix\>Profile Containers\> Cloud Cache

- CCD Location \(Set it to Enabled then under CCD Locations then enter your ZFSSA share path: type=smb, name=””,connectionString=‘\\\<smb\-share\>’ Example: type=smb,name=”SMB Primary”,connectionString=\\10\.20\.2\.79

- Clear Cache on Logoff \(set itset it to Enabled\)

- Healthy Providers Required for Register \(set it to Enabled and value = 1\)





# Task 5 — Create a custom image and test FSLogix

